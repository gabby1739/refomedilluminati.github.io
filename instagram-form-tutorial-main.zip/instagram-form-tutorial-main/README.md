# instagram-form-tutorial
Instagram sign in form cloned using HTML and CSS

[Live Preview](https://htmlpreview.github.io/?https://github.com/russs123/instagram-form-tutorial/blob/main/index.html)
